# 🎯 UC Yutuq Bot — O'rnatish Qo'llanmasi

## 📋 Talablar
- Node.js 18+
- Telegram Bot Token (@BotFather dan)

---

## 🚀 O'rnatish

### 1. Fayllarni yuklab oling

```bash
# Papkaga kiring
cd uc-bot

# Paketlarni o'rnating
npm install
```

### 2. Bot tokenini sozlang

`.env` fayl yarating:
```bash
cp .env.example .env
```

`.env` faylni oching va token kiriting:
```
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ
```

### 3. Admin ID ni sozlang

`config.js` faylni oching:
```js
const ADMIN_IDS = [
  123456789,  // <-- Bu yerga o'z Telegram ID ingizni yozing
];
```

> Telegram ID ni bilish uchun: @userinfobot ga /start yuboring

### 4. Botni ishga tushiring

```bash
node index.js
```

---

## 🌐 Render.com da Deploy (Bepul Hosting)

### 1. GitHub ga yuklang
```bash
git init
git add .
git commit -m "first commit"
git remote add origin https://github.com/USERNAME/uc-bot.git
git push -u origin main
```

### 2. Render.com da:
1. render.com ga kiring
2. "New Web Service" bosing
3. GitHub repo ni ulang
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node index.js`
5. Environment Variables ga `BOT_TOKEN` qo'shing
6. Deploy bosing ✅

---

## 📱 Bot Funksiyalari

### Foydalanuvchi uchun:
| Buyruq | Vazifa |
|--------|--------|
| /start | Botni boshlash |
| 🎮 O'yin o'ynash | O'yin menuini ochish |
| 🔴 / 🔵 | Rang tanlash |
| 💰 Balansim | Balansni ko'rish |
| 🏆 UC Hisobim | UC miqdorini ko'rish |
| 🎁 UC Olish | UC chiqarish so'rovi |
| 💳 Hisob To'ldirish | Chek yuborish |

### Admin uchun:
| Buyruq | Vazifa |
|--------|--------|
| /admin | Admin panel |
| 👥 Userlar | Barcha userlar ro'yxati |
| 💸 Balans Qo'sh | Userga balans qo'shish |
| 📋 So'rovlar | UC chiqarish so'rovlari |
| 🧾 Cheklar | To'lov cheklari |

---

## ⚙️ O'yin Mexanikasi

- Har urinish: **-3,000 so'm**
- Har **5-urinishda** 1 ta yutuq
- Yutuq: **+60 UC**
- Natija foydalanuvchiga random ko'rinadi

---

## 💡 Karta ma'lumotlarini o'zgartirish

`index.js` faylida `showTopup` funksiyasini toping:

```js
`🏦 Karta: \`8600 0000 0000 0000\`\n` +
`👤 Egasi: Admin\n`
```

O'z karta raqamingizni kiriting.

---

## 🆘 Muammo bo'lsa

Telegram: @your_support_username
