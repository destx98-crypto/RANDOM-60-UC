// ⚠️ BU YERGA O'Z ADMIN ID LARINGIZNI KIRITING
const ADMIN_IDS = [
  123456789,   // <-- O'z Telegram ID ingizni kiriting
];

function isAdmin(userId) {
  return ADMIN_IDS.includes(Number(userId));
}

module.exports = { ADMIN_IDS, isAdmin };
