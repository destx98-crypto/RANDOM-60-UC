const TelegramBot = require('node-telegram-bot-api');
const db = require('./database');
const { isAdmin, ADMIN_IDS } = require('./config');

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

// State management
const userStates = {};

// ==================== START ====================
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name;

  let user = db.getUser(userId);
  if (!user) {
    db.createUser(userId, username);
    user = db.getUser(userId);
  }

  showMainMenu(chatId, userId);
});

// ==================== MAIN MENU ====================
function showMainMenu(chatId, userId) {
  const user = db.getUser(userId);
  if (!user) return;

  const keyboard = {
    reply_markup: {
      keyboard: [
        [{ text: '🎮 O\'yin o\'ynash' }],
        [{ text: '💰 Balansim' }, { text: '🏆 UC Hisobim' }],
        [{ text: '🎁 UC Olish' }, { text: '💳 Hisob To\'ldirish' }],
      ],
      resize_keyboard: true,
    },
  };

  bot.sendMessage(chatId,
    `👋 Xush kelibsiz, *${user.username}*!\n\n` +
    `💵 Balans: *${user.balance.toLocaleString()} so'm*\n` +
    `🏆 UC: *${user.uc} UC*\n\n` +
    `O'yin o'ynash uchun "🎮 O'yin o'ynash" ni bosing!`,
    { parse_mode: 'Markdown', ...keyboard }
  );
}

// ==================== MESSAGES ====================
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;

  if (!text) return;
  if (text.startsWith('/')) return;

  const user = db.getUser(userId);

  // Admin panel
  if (isAdmin(userId)) {
    if (userStates[userId]?.action === 'admin_add_balance') {
      handleAdminAddBalance(chatId, userId, text);
      return;
    }
    if (userStates[userId]?.action === 'admin_find_user') {
      handleAdminFindUser(chatId, userId, text);
      return;
    }
  }

  // User states
  if (userStates[userId]?.action === 'enter_pubg_id') {
    handlePubgId(chatId, userId, text);
    return;
  }
  if (userStates[userId]?.action === 'enter_check') {
    handleCheckSubmit(chatId, userId, text);
    return;
  }

  switch (text) {
    case '🎮 O\'yin o\'ynash':
      showGameMenu(chatId, userId);
      break;
    case '💰 Balansim':
      showBalance(chatId, userId);
      break;
    case '🏆 UC Hisobim':
      showUC(chatId, userId);
      break;
    case '🎁 UC Olish':
      showWithdrawMenu(chatId, userId);
      break;
    case '💳 Hisob To\'ldirish':
      showTopup(chatId, userId);
      break;
    case '🔴 Qizil':
    case '🔵 Ko\'k':
      handleGameChoice(chatId, userId, text);
      break;
    case '🔙 Orqaga':
      showMainMenu(chatId, userId);
      break;
    case '👑 Admin Panel':
      if (isAdmin(userId)) showAdminPanel(chatId, userId);
      break;
    case '👥 Userlar':
      if (isAdmin(userId)) showAllUsers(chatId, userId);
      break;
    case '💸 Balans Qo\'sh':
      if (isAdmin(userId)) startAdminAddBalance(chatId, userId);
      break;
    case '📋 So\'rovlar':
      if (isAdmin(userId)) showWithdrawRequests(chatId, userId);
      break;
    case '🧾 Cheklar':
      if (isAdmin(userId)) showChecks(chatId, userId);
      break;
  }
});

// ==================== GAME ====================
function showGameMenu(chatId, userId) {
  const user = db.getUser(userId);
  const GAME_COST = 3000;

  if (user.balance < GAME_COST) {
    bot.sendMessage(chatId,
      `❌ Balansingiz yetarli emas!\n\n` +
      `💵 Balans: *${user.balance.toLocaleString()} so'm*\n` +
      `🎮 O'yin narxi: *${GAME_COST.toLocaleString()} so'm*\n\n` +
      `Admin orqali balans to'ldiring.`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          keyboard: [[{ text: '🔙 Orqaga' }]],
          resize_keyboard: true,
        }
      }
    );
    return;
  }

  bot.sendMessage(chatId,
    `🎮 *O'YIN*\n\n` +
    `💵 Balans: *${user.balance.toLocaleString()} so'm*\n` +
    `🎯 Har urinish: *-3,000 so'm*\n\n` +
    `🔴 yoki 🔵 ni tanlang!`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [
          [{ text: '🔴 Qizil' }, { text: '🔵 Ko\'k' }],
          [{ text: '🔙 Orqaga' }],
        ],
        resize_keyboard: true,
      }
    }
  );
}

function handleGameChoice(chatId, userId, choice) {
  const GAME_COST = 3000;
  const UC_REWARD = 60;

  const user = db.getUser(userId);

  if (user.balance < GAME_COST) {
    bot.sendMessage(chatId, '❌ Balansingiz yetarli emas!');
    showMainMenu(chatId, userId);
    return;
  }

  // Deduct balance
  db.updateBalance(userId, -GAME_COST);

  // Increment global counter & check win
  const counter = db.incrementCounter();
  const isWin = counter % 5 === 0;

  // Random result for display (always looks random to user)
  const results = ['🔴 Qizil', '🔵 Ko\'k'];
  const displayResult = results[Math.floor(Math.random() * 2)];
  const userChoice = choice === '🔴 Qizil' ? '🔴 Qizil' : '🔵 Ko\'k';

  // Log attempt
  db.logAttempt(userId, userChoice, displayResult, isWin);

  if (isWin) {
    db.addUC(userId, UC_REWARD);
    const updatedUser = db.getUser(userId);

    bot.sendMessage(chatId,
      `🎉 *TABRIKLAYMIZ! YUTDINGIZ!*\n\n` +
      `Siz tanladingiz: ${userChoice}\n` +
      `Natija: ${displayResult}\n\n` +
      `🏆 *+${UC_REWARD} UC qo'shildi!*\n\n` +
      `💵 Balans: *${updatedUser.balance.toLocaleString()} so'm*\n` +
      `🏆 Jami UC: *${updatedUser.uc} UC*`,
      { parse_mode: 'Markdown' }
    );
  } else {
    const updatedUser = db.getUser(userId);

    bot.sendMessage(chatId,
      `😔 *Yutmadingiz*\n\n` +
      `Siz tanladingiz: ${userChoice}\n` +
      `Natija: ${displayResult}\n\n` +
      `💵 Balans: *${updatedUser.balance.toLocaleString()} so'm*\n` +
      `🏆 UC: *${updatedUser.uc} UC*\n\n` +
      `Yana urinib ko'ring! 💪`,
      { parse_mode: 'Markdown' }
    );
  }
}

// ==================== BALANCE ====================
function showBalance(chatId, userId) {
  const user = db.getUser(userId);
  bot.sendMessage(chatId,
    `💵 *BALANSIM*\n\n` +
    `So'm: *${user.balance.toLocaleString()} so'm*\n` +
    `🏆 UC: *${user.uc} UC*`,
    { parse_mode: 'Markdown' }
  );
}

function showUC(chatId, userId) {
  const user = db.getUser(userId);
  bot.sendMessage(chatId,
    `🏆 *UC HISOBIM*\n\n` +
    `Jami UC: *${user.uc} UC*\n\n` +
    `UC olish uchun "🎁 UC Olish" ni bosing.`,
    { parse_mode: 'Markdown' }
  );
}

// ==================== WITHDRAW ====================
function showWithdrawMenu(chatId, userId) {
  const user = db.getUser(userId);

  if (user.uc <= 0) {
    bot.sendMessage(chatId,
      `❌ UC balansingiz 0!\n\nAvval o'yin o'ynab UC yig'ing.`,
      {
        reply_markup: {
          keyboard: [[{ text: '🔙 Orqaga' }]],
          resize_keyboard: true,
        }
      }
    );
    return;
  }

  userStates[userId] = { action: 'enter_pubg_id' };

  bot.sendMessage(chatId,
    `🎁 *UC OLISH*\n\n` +
    `UC balansingiz: *${user.uc} UC*\n\n` +
    `PUBG Mobile ID ingizni kiriting:`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [[{ text: '🔙 Orqaga' }]],
        resize_keyboard: true,
      }
    }
  );
}

function handlePubgId(chatId, userId, pubgId) {
  if (pubgId === '🔙 Orqaga') {
    delete userStates[userId];
    showMainMenu(chatId, userId);
    return;
  }

  const user = db.getUser(userId);

  // Save withdraw request
  db.createWithdrawRequest(userId, user.username, pubgId, user.uc);

  // Reset UC
  db.resetUC(userId);

  delete userStates[userId];

  // Notify admins
  ADMIN_IDS.forEach(adminId => {
    bot.sendMessage(adminId,
      `🔔 *YANGI UC SO'ROV*\n\n` +
      `👤 User: @${user.username} (ID: ${userId})\n` +
      `🎮 PUBG ID: \`${pubgId}\`\n` +
      `🏆 UC miqdori: *${user.uc} UC*`,
      { parse_mode: 'Markdown' }
    ).catch(() => {});
  });

  bot.sendMessage(chatId,
    `✅ *So'rovingiz qabul qilindi!*\n\n` +
    `🎮 PUBG ID: \`${pubgId}\`\n` +
    `🏆 UC: *${user.uc} UC*\n\n` +
    `Admin tez orada UC yuboradi. Kuting! ⏳`,
    { parse_mode: 'Markdown' }
  );

  showMainMenu(chatId, userId);
}

// ==================== TOPUP ====================
function showTopup(chatId, userId) {
  userStates[userId] = { action: 'enter_check' };

  bot.sendMessage(chatId,
    `💳 *HISOB TO'LDIRISH*\n\n` +
    `📱 To'lov rekvizitlari:\n\n` +
    `🏦 Karta: \`8600 0000 0000 0000\`\n` +
    `👤 Egasi: Admin\n\n` +
    `💡 To'lov qilib, chek (screenshot) yuboring:\n` +
    `_(Chekni bu yerga yuboring)_`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [[{ text: '🔙 Orqaga' }]],
        resize_keyboard: true,
      }
    }
  );
}

function handleCheckSubmit(chatId, userId, text) {
  if (text === '🔙 Orqaga') {
    delete userStates[userId];
    showMainMenu(chatId, userId);
    return;
  }

  const user = db.getUser(userId);
  db.saveCheck(userId, user.username, text);
  delete userStates[userId];

  ADMIN_IDS.forEach(adminId => {
    bot.sendMessage(adminId,
      `🧾 *YANGI CHEK*\n\n` +
      `👤 User: @${user.username} (ID: ${userId})\n` +
      `📝 Ma'lumot: ${text}`,
      { parse_mode: 'Markdown' }
    ).catch(() => {});
  });

  bot.sendMessage(chatId,
    `✅ Chekingiz adminga yuborildi!\n\nAdmin tekshirib, balans qo'shadi. ⏳`
  );

  showMainMenu(chatId, userId);
}

// ==================== PHOTO CHECKS ====================
bot.on('photo', (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (userStates[userId]?.action === 'enter_check') {
    const user = db.getUser(userId);
    const fileId = msg.photo[msg.photo.length - 1].file_id;
    db.saveCheck(userId, user.username, `[RASM] fileId: ${fileId}`);
    delete userStates[userId];

    ADMIN_IDS.forEach(adminId => {
      bot.sendPhoto(adminId, fileId, {
        caption: `🧾 *YANGI CHEK (RASM)*\n\n👤 User: @${user.username} (ID: ${userId})`,
        parse_mode: 'Markdown'
      }).catch(() => {});
    });

    bot.sendMessage(chatId, `✅ Chek rasmi adminga yuborildi! ⏳`);
    showMainMenu(chatId, userId);
  }
});

// ==================== ADMIN PANEL ====================
bot.onText(/\/admin/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!isAdmin(userId)) return;
  showAdminPanel(chatId, userId);
});

function showAdminPanel(chatId, userId) {
  bot.sendMessage(chatId,
    `👑 *ADMIN PANEL*`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [
          [{ text: '👥 Userlar' }, { text: '💸 Balans Qo\'sh' }],
          [{ text: '📋 So\'rovlar' }, { text: '🧾 Cheklar' }],
          [{ text: '🔙 Orqaga' }],
        ],
        resize_keyboard: true,
      }
    }
  );
}

function showAllUsers(chatId, userId) {
  const users = db.getAllUsers();
  if (!users.length) {
    bot.sendMessage(chatId, 'Hali hech kim ro\'yxatdan o\'tmagan.');
    return;
  }

  let text = `👥 *BARCHA USERLAR* (${users.length} ta)\n\n`;
  users.forEach((u, i) => {
    text += `${i + 1}. @${u.username} (${u.user_id})\n`;
    text += `   💵 ${u.balance.toLocaleString()} so'm | 🏆 ${u.uc} UC\n\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
}

function startAdminAddBalance(chatId, userId) {
  userStates[userId] = { action: 'admin_find_user' };
  bot.sendMessage(chatId,
    `💸 Balans qo'shish\n\nUser ID yoki username kiriting:`,
    {
      reply_markup: {
        keyboard: [[{ text: '🔙 Orqaga' }]],
        resize_keyboard: true,
      }
    }
  );
}

function handleAdminFindUser(chatId, userId, text) {
  if (text === '🔙 Orqaga') {
    delete userStates[userId];
    showAdminPanel(chatId, userId);
    return;
  }

  const targetUser = db.findUser(text);
  if (!targetUser) {
    bot.sendMessage(chatId, `❌ User topilmadi: ${text}`);
    return;
  }

  userStates[userId] = {
    action: 'admin_add_balance',
    targetUserId: targetUser.user_id,
    targetUsername: targetUser.username,
  };

  bot.sendMessage(chatId,
    `✅ User topildi: @${targetUser.username}\n` +
    `💵 Joriy balans: ${targetUser.balance.toLocaleString()} so'm\n\n` +
    `Qo'shmoqchi bo'lgan summani kiriting (so'mda):`
  );
}

function handleAdminAddBalance(chatId, userId, text) {
  if (text === '🔙 Orqaga') {
    delete userStates[userId];
    showAdminPanel(chatId, userId);
    return;
  }

  const amount = parseInt(text.replace(/\s/g, ''));
  if (isNaN(amount) || amount <= 0) {
    bot.sendMessage(chatId, '❌ Noto\'g\'ri summa! Faqat raqam kiriting.');
    return;
  }

  const { targetUserId, targetUsername } = userStates[userId];
  db.updateBalance(targetUserId, amount);
  delete userStates[userId];

  const updatedUser = db.getUser(targetUserId);

  bot.sendMessage(chatId,
    `✅ *Balans qo'shildi!*\n\n` +
    `👤 User: @${targetUsername}\n` +
    `➕ Qo'shildi: *${amount.toLocaleString()} so'm*\n` +
    `💵 Yangi balans: *${updatedUser.balance.toLocaleString()} so'm*`,
    { parse_mode: 'Markdown' }
  );

  // Notify user
  bot.sendMessage(targetUserId,
    `🎉 *Balansingiz to'ldirildi!*\n\n` +
    `➕ *+${amount.toLocaleString()} so'm*\n` +
    `💵 Joriy balans: *${updatedUser.balance.toLocaleString()} so'm*`,
    { parse_mode: 'Markdown' }
  ).catch(() => {});

  showAdminPanel(chatId, userId);
}

function showWithdrawRequests(chatId, userId) {
  const requests = db.getWithdrawRequests();
  if (!requests.length) {
    bot.sendMessage(chatId, '📋 Hali so\'rov yo\'q.');
    return;
  }

  let text = `📋 *UC SO'ROVLAR* (${requests.length} ta)\n\n`;
  requests.forEach((r, i) => {
    text += `${i + 1}. @${r.username}\n`;
    text += `   🎮 PUBG ID: \`${r.pubg_id}\`\n`;
    text += `   🏆 UC: *${r.uc_amount} UC*\n`;
    text += `   📅 ${new Date(r.created_at).toLocaleString('uz-UZ')}\n\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
}

function showChecks(chatId, userId) {
  const checks = db.getChecks();
  if (!checks.length) {
    bot.sendMessage(chatId, '🧾 Hali chek yo\'q.');
    return;
  }

  let text = `🧾 *CHEKLAR* (${checks.length} ta)\n\n`;
  checks.forEach((c, i) => {
    text += `${i + 1}. @${c.username} (${c.user_id})\n`;
    text += `   📝 ${c.check_data}\n`;
    text += `   📅 ${new Date(c.created_at).toLocaleString('uz-UZ')}\n\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
}

console.log('🤖 Bot ishga tushdi!');
